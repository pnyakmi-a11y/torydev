# TSS BOT — Tory Store SAMP

Discord bot untuk store, mini-games, verifikasi member, dan sistem tiket pesanan.

## Fitur

- **Store**: katalog produk + form order → otomatis bikin **tiket privat** per pesanan
- **Pembayaran**: QRIS / BCA / Mandiri / DANA / GoPay / OVO
- **Upload bukti**: user cukup kirim foto langsung di channel tiket (no link)
- **Verifikasi admin**: tombol Approve / Reject di tiket → DM otomatis ke buyer
- **Auto-role**: produk role otomatis terpasang saat lunas
- **Sistem tiket umum**: `/setup-ticket` (Order Manual / Bantuan / Komplain)
- **Verifikasi member**: tombol verify → kasih role
- **Mini games**: slot, dadu, suit, coinflip dengan saldo coin + `/daily`
- **Pengumuman**: `/announce` embed ungu
- **Presence**: streaming "Tory Store SAMP" (warna ungu)

## Setup

### 1. Install
```bash
npm install
```

### 2. Konfigurasi env
```bash
cp .env.example .env
# lalu edit .env, isi token & ID
```

### 3. Wajib aktifkan di Discord Developer Portal
Bot → tab **Bot** → **Privileged Gateway Intents** centang:
- ✅ SERVER MEMBERS INTENT
- ✅ MESSAGE CONTENT INTENT
- ✅ PRESENCE INTENT

### 4. Permission bot saat invite ke server
- Manage Roles
- Manage Channels
- Send Messages
- Embed Links
- Attach Files
- Read Message History
- Use Slash Commands

### 5. Jalankan
```bash
npm start
```

## Cara dapat ID
Aktifkan **Developer Mode** di Discord (Settings → Advanced → Developer Mode).
- **Server ID**: klik kanan nama server → Copy Server ID
- **Role ID**: Server Settings → Roles → klik kanan role → Copy ID
- **Channel/Category ID**: klik kanan channel/category → Copy Channel ID

## Slash Commands

| Command | Fungsi | Akses |
|--------|--------|-------|
| `/setup-verify` | Kirim panel verifikasi | Admin |
| `/setup-store` | Kirim panel store | Admin |
| `/setup-game` | Kirim panel game | Admin |
| `/setup-ticket` | Kirim panel tiket | Admin |
| `/store` | Tampilkan daftar produk | Semua |
| `/game` | Tampilkan menu game | Semua |
| `/balance` | Cek saldo coin | Semua |
| `/daily` | Klaim 100 coin harian | Semua |
| `/orders` | Lihat 10 order terbaru | Admin |
| `/announce` | Kirim pengumuman embed | Admin |

## Catatan
- Semua data (order, balance, tiket) disimpan di **memory** (RAM). Restart = reset.
- Untuk persistence, ganti Map di `src/index.ts` dengan SQLite/Postgres/JSON file sesuai kebutuhan.
- Posisi role bot harus **lebih tinggi** dari role yang akan diberikan ke member.
